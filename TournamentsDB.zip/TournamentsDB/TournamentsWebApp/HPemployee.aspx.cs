﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Group_14_Project
{
    public partial class HPemployee : System.Web.UI.Page
    {
        public SqlConnection conn;
        public SqlCommand comm;
        public DataSet ds;
        public SqlDataAdapter adap;
        public string constr = @"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\TournamentsDB.mdf;Integrated Security = True; Connect Timeout = 30";

        protected void Page_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(constr);
            string sql_Matches = "SELECT * FROM MatchInfo";
            string sql_EName = "SELCT FirstName,LastName FROM EmployeeInfo";
            string sql_EId = "SELECT Id FROM EmployeeInfo";
            conn.Open();

            //Tournaments
            ds = new DataSet();
            adap = new SqlDataAdapter();

            comm = new SqlCommand(sql_Matches, conn);
            adap.SelectCommand = comm;
            adap.Fill(ds);

            gdvTeamScores.DataSource = ds;
            gdvTeamScores.DataBind();

            //Employee
            lblEmpName.Text = "Welcome" + sql_EName;
            lblEmpID.Text = "Team ID: " + sql_EId;
            
            conn.Close();
        }

        protected void btnPScores_Click(object sender, EventArgs e)
        {
            Response.Redirect(".aspx");
        }

        protected void btnAddT_Click(object sender, EventArgs e)
        {
            Response.Redirect("createTournament.aspx");
        }

        protected void btnPTeams_Click(object sender, EventArgs e)
        {
            Response.Redirect("UpdateTeam.aspx");
        }

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

		protected void Button1_Click(object sender, EventArgs e)
		{
            Response.Redirect("createReport.aspx");
		}
	}
}