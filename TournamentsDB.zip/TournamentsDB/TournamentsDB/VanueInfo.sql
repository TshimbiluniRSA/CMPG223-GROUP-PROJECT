﻿CREATE TABLE [dbo].[VanueInfo]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [VenueName] NCHAR(30) NULL, 
    [Location] NCHAR(30) NULL
)
