﻿CREATE TABLE [dbo].[TeamsInfo]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [TeamName] NCHAR(40) NULL,  
    [Team_website] NVARCHAR(2000) NULL
)
